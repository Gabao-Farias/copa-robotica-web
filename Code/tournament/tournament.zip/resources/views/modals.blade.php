<div class="modal fade{{ (isset($darkTheme) && $darkTheme) ? ' dark' : '' }}" tabindex="-1" role="dialog" id="app-modal" style="margin-top: 50px;">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title"></h4>
            </div>
            <div class="modal-body">
                
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default first-button" data-dismiss="modal"></button>
                <button type="button" class="btn btn-primary second-button"></button>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->