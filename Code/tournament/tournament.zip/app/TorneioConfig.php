<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TorneioConfig extends Model
{
    protected $fillable = ['nome', 'valor'];
}
