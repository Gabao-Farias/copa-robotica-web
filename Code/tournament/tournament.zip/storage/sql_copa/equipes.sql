/*
SQLyog Ultimate v10.00 Beta1
MySQL - 5.1.46-log 
*********************************************************************
*/
/*!40101 SET NAMES utf8 */;

create table `` (
	`cod` int ,
	`nome` varchar ,
	`evento` varchar ,
	`cancelada` int 
); 
-- insert into `` (`cod`, `nome`, `evento`, `cancelada`) values('41','Colégio Tiradentes','copa_robotica2016|R-38','0');
-- insert into `` (`cod`, `nome`, `evento`, `cancelada`) values('42','Joker 2000','copa_robotica2016|R-40','0'); --Missões
-- insert into `` (`cod`, `nome`, `evento`, `cancelada`) values('44','Robot squad','copa_robotica2016|R-54','0'); --IF Rui Barbosa
-- insert into `` (`cod`, `nome`, `evento`, `cancelada`) values('46','TEEM ASSMANN','copa_robotica2016|R-53','0'); --Onofre
-- insert into `` (`cod`, `nome`, `evento`, `cancelada`) values('47','HAKUHO','copa_robotica2016|R-57','0'); --URI
-- insert into `` (`cod`, `nome`, `evento`, `cancelada`) values('48','João 23','copa_robotica2016|R-52','0');
-- insert into `` (`cod`, `nome`, `evento`, `cancelada`) values('49','Team Wall-E','copa_robotica2016|R-58','0'); --Catuípe
-- insert into `` (`cod`, `nome`, `evento`, `cancelada`) values('50','Pacelli 2016','copa_robotica2016|R-61','0'); --Pacelli
-- insert into `` (`cod`, `nome`, `evento`, `cancelada`) values('51','HAIL DIORNE!','copa_robotica2016|R-44','0'); --Marista
-- insert into `` (`cod`, `nome`, `evento`, `cancelada`) values('52','Fortrek','copa_robotica2016|R-73','0'); --Eugênio Frantz
-- insert into `` (`cod`, `nome`, `evento`, `cancelada`) values('53','ROBÓTICA GETÚLIO 2016 II','copa_robotica2016|R-72','0'); --Getúlio
-- insert into `` (`cod`, `nome`, `evento`, `cancelada`) values('54','Equipe La Salle Medianeira','copa_robotica2016|R-69','0');
-- insert into `` (`cod`, `nome`, `evento`, `cancelada`) values('55','Roboeduc UCM','copa_robotica2016|R-76','0'); --Unirio
-- insert into `` (`cod`, `nome`, `evento`, `cancelada`) values('56','Pedro II','copa_robotica2016|R-63','0');
-- insert into `` (`cod`, `nome`, `evento`, `cancelada`) values('57','AutoBot','copa_robotica2016|R-58','0'); --Catuipe
-- insert into `` (`cod`, `nome`, `evento`, `cancelada`) values('58','Robótica DH','copa_robotica2016|R-64','0'); --Dom Hermeto
-- insert into `` (`cod`, `nome`, `evento`, `cancelada`) values('59','ROBOSSAUROS','copa_robotica2016|R-70','0'); --Antonio Sepp
-- insert into `` (`cod`, `nome`, `evento`, `cancelada`) values('62','ROBÓTICA GETÚLIO 2016 I','copa_robotica2016|R-72','0');
-- insert into `` (`cod`, `nome`, `evento`, `cancelada`) values('63','Augusto','copa_robotica2016|R-79','0');
-- insert into `` (`cod`, `nome`, `evento`, `cancelada`) values('70','Black Angels','copa_robotica2016|R-61','0'); --Pacelli
-- insert into `` (`cod`, `nome`, `evento`, `cancelada`) values('83','F5 (Atualiza)','copa_robotica2016|R-88','0'); --Buriti
-- insert into `` (`cod`, `nome`, `evento`, `cancelada`) values('84','B23','copa_robotica2016|R-88','0'); --Buriti
-- insert into `` (`cod`, `nome`, `evento`, `cancelada`) values('85','Optimus','copa_robotica2016|R-56','0'); --Odão
-- insert into `` (`cod`, `nome`, `evento`, `cancelada`) values('87','MISSOES NOTURNO','copa_robotica2016|R-91','0');
-- insert into `` (`cod`, `nome`, `evento`, `cancelada`) values('98','Escola Augusto - Irena','copa_robotica2016|R-56','0');
