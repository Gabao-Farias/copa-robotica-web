

<?php $__env->startSection('page-title', 'Chaveamento'); ?>

<?php $__env->startSection('content'); ?>
    <input type="hidden" id="chaveamento-data" value="<?php echo e(json_encode($chaveamento)); ?>">
    <div class="container">
        <h1 class="text-uppercase chaveamento-title">Eliminatórias - Copa URI de Robótica <?php echo e(date('Y')); ?></h1>
        <div class="chaveamento"></div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('assets'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('js/jquery-bracket-master/dist/jquery.bracket.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/bracket-tweaks.css')); ?>">
    <script src="<?php echo e(asset('js/jquery-bracket-master/dist/jquery.bracket.min.js')); ?>"></script>
    <script>
        $(function () {
            Echo.channel('chaveamento')
                    .listen('UpdateChaveamentoEvent', function (e) {
                        location.reload();
                    });

            $('.chaveamento').bracket(JSON.parse($('#chaveamento-data').val()));

            var hasWinners = '<?php echo e($hasWinners); ?>';
            if (parseInt(hasWinners)) {
                setTimeout(function() {
                    window.location.href = '<?php echo e(url('vencedores')); ?>';
                }, 10000);
            }
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>