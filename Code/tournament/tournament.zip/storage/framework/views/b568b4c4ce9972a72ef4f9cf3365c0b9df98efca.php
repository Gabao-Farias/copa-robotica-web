

<?php $__env->startSection('page-title', 'Ringues do Torneio'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-sm-10 col-sm-offset-1">
                <div class="panel panel-dark">
                    <div class="panel-heading">
                        Ringues do Torneio
                    </div>
                    <ul class="list-group dark">
                        <?php $__currentLoopData = $ringues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ringue): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            <li class="list-group-item">
                                <?php echo e($ringue->nome); ?>

                                <span class="pull-right">
                                    <button class="btn btn-sm btn-default dark assistir<?php echo e((Request::cookie('ringue_assistindo') == $ringue->id) ? ' disabled' : ''); ?>" id="<?php echo e($ringue->id); ?>">
                                        <span class="glyphicon glyphicon-eye-open"></span>
                                        <span class="watch-text">
                                            <?php if(Request::cookie('ringue_assistindo') == $ringue->id): ?>
                                                Assistindo
                                            <?php else: ?>
                                                Assistir
                                            <?php endif; ?>
                                        </span>
                                    </button>
                                </span>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('assets'); ?>
    <script src="<?php echo e(asset('js/RingueWatcher.js')); ?>"></script>
    <script>
        $(function() {
            var watcher = new RingueWatcher();

            <?php if(! is_null(Request::cookie('ringue_assistindo'))): ?>
                watcher.watch(<?php echo e(Request::cookie('ringue_assistindo')); ?>);
            <?php endif; ?>
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>