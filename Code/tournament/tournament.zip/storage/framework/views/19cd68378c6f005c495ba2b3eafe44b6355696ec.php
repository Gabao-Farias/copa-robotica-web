<div class="panel-group">
    <?php $__currentLoopData = $batalhas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $batalha): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
        <div class="row batalha">
            <div class="col-sm-5">
                <div class="panel panel-dark">
                    <div class="panel-heading">
                        <?php echo e($batalha->equipe1->nome); ?>

                    </div>
                    <a href="<?php echo e(Helpers::resolverFotoEquipe($batalha->equipe1)); ?>" target="_blank">
                        <img class="media-object foto-equipe-round" src="<?php echo e(Helpers::resolverFotoEquipe($batalha->equipe1)); ?>" alt="FOTO">
                    </a>
                </div>
            </div>
            <div class="col-sm-2">
                <div class="versus-align">
                    <div class="versus-container">
                        <span class="text">
                            VS
                        </span>
                    </div>
                </div>
            </div>
            <div class="col-sm-5">
                <div class="panel panel-dark">
                    <div class="panel-heading">
                        <?php echo e($batalha->equipe2->nome); ?>

                    </div>
                    <a href="<?php echo e(Helpers::resolverFotoEquipe($batalha->equipe2)); ?>" target="_blank">
                        <img class="media-object foto-equipe-round" src="<?php echo e(Helpers::resolverFotoEquipe($batalha->equipe2)); ?>" alt="FOTO">
                    </a>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
</div>