<div class="panel-group">
	<?php $__currentLoopData = $batalhas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $batalha): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		<div class="panel panel-default">
			<div class="panel-heading">
				<div class="clearfix">
					<strong><?php echo e($batalha->equipe1->nome); ?> (VS) <?php echo e($batalha->equipe2->nome); ?></strong> (<?php echo e(Helpers::resolverStatusBatalha($batalha->status)); ?>)
					<?php if((! isset($view_only) || ! $view_only)): ?>
                        <div class="pull-right">
                        	<?php if($batalha->status == 'em_andamento'): ?>
                        		<?php if($batalha->rounds()->ordem()->ativo()->count()): ?>
	                        		<a href="<?php echo e(url('admin/torneio/round/' . $batalha->rounds()->ordem()->ativo()->first()->id)); ?>" class="btn btn-sm btn-default">
	                            		Continuar Batalha
	                            	</a>
                            	<?php else: ?>
                            		<a href="<?php echo e(url('admin/torneio/round/' . $batalha->rounds()->ordem()->concluido()->first()->id)); ?>" class="btn btn-sm btn-default">
	                            		Continuar Batalha
	                            	</a>
                            	<?php endif; ?>
                            <?php elseif($batalha->status == 'nao_iniciada'): ?>
	                            <a href="<?php echo e(url('admin/torneio/batalha/' . $batalha->id . '/iniciar')); ?>" class="btn btn-sm btn-default">
	                            	Iniciar Batalha
	                            </a>
                            <?php endif; ?>
                        </div>
					<?php endif; ?>
				</div>
			</div>
			<div class="row">
				<div class="col-sm-5">
					<div class="media">
						<div class="media-left">
							<a href="<?php echo e(Helpers::resolverFotoRobo($batalha->equipe1)); ?>" target="_blank">
								<img class="media-object foto-equipe-batalha-generator" src="<?php echo e(Helpers::resolverFotoRobo($batalha->equipe1)); ?>" alt="FOTO">
							</a>
						</div>
						<div class="media-body">
							<p class="media-heading font-bold batalha-equipe-heading">
								<?php if($batalha->equipe_vencedora_id == $batalha->equipe1->id): ?>
                                    <span class="glyphicon glyphicon-star text-warning" title="Vencedor" data-toggle="tooltip" style="cursor: pointer;"></span>
                                <?php endif; ?>
                                <?php echo e($batalha->equipe1->nome); ?>

							</p>
							<p><?php echo e($batalha->equipe1->escola->nome); ?></p>
						</div>
					</div>
				</div>
				<div class="col-sm-2">
					<div class="clearfix">
						<span class="batalha-versus">VS</span>
					</div>
				</div>
				<div class="col-sm-5">
					<div class="media">
						<div class="media-body text-right">
							<p class="media-heading font-bold batalha-equipe-heading">
                                <?php if($batalha->equipe_vencedora_id == $batalha->equipe2->id): ?>
                                    <span class="glyphicon glyphicon-star text-warning" title="Vencedor" data-toggle="tooltip" style="cursor: pointer;"></span>
                                <?php endif; ?>
                                <?php echo e($batalha->equipe2->nome); ?>

                            </p>
							<p><?php echo e($batalha->equipe2->escola->nome); ?></p>
						</div>
						<div class="media-right">
							<a href="<?php echo e(Helpers::resolverFotoRobo($batalha->equipe2)); ?>" target="_blank">
								<img class="media-object foto-equipe-batalha-generator" src="<?php echo e(Helpers::resolverFotoRobo($batalha->equipe2)); ?>" alt="FOTO">
							</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
</div>