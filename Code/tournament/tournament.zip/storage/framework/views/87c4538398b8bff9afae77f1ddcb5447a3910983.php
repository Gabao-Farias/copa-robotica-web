<!DOCTYPE html>
<html>
<head>
	<title>Copa URI de Robótica - <?php echo e(date('Y')); ?></title>
	<link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/placar.css')); ?>">
</head>
<body>
	<div class="wrapper-md">
		<h1 class="text-uppercase">Resultados Copa URI de Robótica - <?php echo e(date('Y')); ?></h1>
		<div class="row less-gutter">
			<div class="col-sm-4">
				<div class="panel panel-default">
					<div class="panel-heading">
						Dados Gerais de Equipes
					</div>
					<div class="table-responsive">
						<table class="table table-striped">
							<tr>
								<th>Equipe</th>
								<th>V</th>
								<th>Ippon</th>
								<th>Pontos</th>
							</tr>
							<?php for($i = 0; $i < $porPagina; $i++): ?>
								<tr>
									<td><?php echo e($equipes->get($i)->nome); ?></td>
									<td><?php echo e(mt_rand(0, 10)); ?></td>
									<td><?php echo e(mt_rand(0, 3)); ?></td>
									<td><?php echo e(mt_rand(0, 100)); ?></td>
								</tr>
							<?php endfor; ?>
						</table>
					</div>
				</div>
			</div>
			<div class="col-sm-4">
				<div class="panel panel-default">
					<div class="panel-heading">
						Dados Gerais de Equipes
					</div>
					<div class="table-responsive">
						<table class="table table-striped">
							<tr>
								<th>Equipe</th>
								<th>V</th>
								<th>Ippon</th>
								<th>Pontos</th>
							</tr>
							<?php for($i--, $j = 1; $j < $porPagina; $j++): ?>
								<tr>
									<td><?php echo e($equipes->get($i + $j)->nome); ?></td>
									<td><?php echo e(mt_rand(0, 10)); ?></td>
									<td><?php echo e(mt_rand(0, 3)); ?></td>
									<td><?php echo e(mt_rand(0, 100)); ?></td>
								</tr>
							<?php endfor; ?>
						</table>
					</div>
				</div>
			</div>
			
	</div>
</body>
</html>