

<?php $__env->startSection('page-title', 'Batalha: ' . $batalha->equipe1->nome . ' VS ' . $batalha->equipe2->nome); ?>

<?php $__env->startSection('content'); ?>
    <div class="row less-gutter">
        <div class="col-sm-12">
            <?php echo $__env->make('round-template', ['batalhas' => [$batalha]], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <input type="hidden" id="round_data" value="<?php echo e($round); ?>">
            <div class="row">
                <div class="col-xs-4">
                    <div class="pontos-container" id="<?php echo e($batalha->equipe1->id); ?>">
                        <?php echo $__env->make('historico-pontos', [
                            'pontos' => $batalha->equipe1
                                ->pontosRound($round)
                                ->latest()
                                ->get(),
                            'equipe' => $batalha->equipe1,
                            'darkTheme' => true,
                            'hideControls' => true
                        ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>
                </div>
                <div class="col-xs-4">
                    <h2 class="round-status-title">Round <?php echo e($round->ordem); ?> <span class="round-status">(<?php echo e(Helpers::resolverStatusRound($round->status)); ?>)</span></h2>
                    <div class="partida-timer" data-time="<?php echo e($round->tempo_restante); ?>" <?php if(! $showTimer): ?> style="display: none;" <?php endif; ?>>
                        <?php echo e(gmdate('i:s', $round->tempo_restante)); ?>

                    </div>
                    <div class="partida-message" <?php if($showTimer): ?> style="display: none;" <?php endif; ?>>
                        Aguardando Árbitro
                    </div>
                </div>
                <div class="col-xs-4">
                    <div class="pontos-container" id="<?php echo e($batalha->equipe2->id); ?>">
                        <?php echo $__env->make('historico-pontos', [
                            'pontos' => $batalha->equipe2
                                ->pontosRound($round)
                                ->latest()
                                ->get(),
                            'equipe' => $batalha->equipe2,
                            'darkTheme' => true,
                            'hideControls' => true
                        ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('assets'); ?>
	<script src="<?php echo e(asset('js/RoundApi.js')); ?>"></script>
	<script src="<?php echo e(asset('js/Round.js')); ?>"></script>
	<script>
		$(function() {
			new Round($('#round_data').val(), true);
		});
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>