

<?php $__env->startSection('page-title', 'Ranking Primeira Fase'); ?>

<?php $__env->startSection('content'); ?>
	<div class="wrapper-md">
		<h1 class="text-uppercase round-status-title" style="margin: 0;">Ranking Primeira Fase - Copa URI de Robótica <?php echo e(date('Y')); ?></h1>
		<div class="row less-gutter">
			<div class="col-sm-6">
				<div class="panel panel-dark">
					<?php echo $__env->make('rankings-list', ['rankings' => $rankings1, 'counter' => $counter1, 'darkTheme' => true], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				</div>
			</div>
			<div class="col-sm-6">
				<div class="panel panel-dark">
					<?php echo $__env->make('rankings-list', ['rankings' => $rankings2, 'counter' => $counter2, 'darkTheme' => true], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('assets'); ?>
    <script>
        $(function () {
            var faseTorneio = '<?php echo e($faseTorneio); ?>';
            Echo.channel('ranking')
                    .listen('RankUpdatedEvent', function (e) {
                        location.reload();
                    });

			$('body').css('overflow', 'hidden');

            if (parseInt(faseTorneio) > 1) {
                setTimeout(function() {
                    window.location.href = '<?php echo e(url('chaveamento')); ?>';
                }, 10000);
            }
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>