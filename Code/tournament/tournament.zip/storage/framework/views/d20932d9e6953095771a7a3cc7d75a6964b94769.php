<?php if($rankings->count()): ?>
    <table class="table table-striped<?php echo e((isset($darkTheme) && $darkTheme) ? ' dark' : ''); ?>">
        <tr>
            <th class="text-center"><strong>#</strong></th>
            <th>Equipe</th>
            <th>V</th>
            <th>Ippon</th>
            <th>Pontos</th>
        </tr>
        <?php $__currentLoopData = $rankings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ranking): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <tr<?php echo ($counter <= 8) ? ' class="highlight"' : ''; ?>>
                <td class="text-center"><strong><?php echo e($counter++); ?></strong></td>
                <td><?php echo e($ranking->equipe->nome); ?></td>
                <td><?php echo e($ranking->vitorias); ?></td>
                <td><?php echo e($ranking->ippons); ?></td>
                <td><?php echo e($ranking->pontos); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
    </table>
<?php else: ?>
    <div class="alert dark alert-warning panel-alert alert-important">
        Não há dados disponíveis no momento.
    </div>
<?php endif; ?>