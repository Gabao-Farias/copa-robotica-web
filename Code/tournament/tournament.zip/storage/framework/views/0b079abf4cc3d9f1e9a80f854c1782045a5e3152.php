

<?php $__env->startSection('page-title', 'Editar Equipe "' . $equipe->nome . '"'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-sm-10 col-sm-offset-1">
                <div class="clearfix">
                    <div class="pull-left">
                        <h1 class="font-thin">Editar Equipe</h1>
                    </div>
                    <div class="pull-right">
                        <a href="<?php echo e(url('admin/equipes')); ?>" class="btn btn-primary action-button">
                            <span class="glyphicon glyphicon-arrow-left glyphicon-margin-right"></span>
                            Voltar
                        </a>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading">
                        Editar Equipe "<?php echo e($equipe->nome); ?>"
                    </div>
                    <div class="panel-body">
                        <?php echo Form::model($equipe, ['url' => url('admin/equipes/editar/' . $equipe->id), 'class' => 'form-horizontal', 'method' => 'POST']); ?>

                    	   <?php echo $__env->make('admin.equipes.form', ['button' => 'Editar', 'mode' => 'edit'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <?php echo Form::close(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('assets'); ?>
    <script src="<?php echo e(asset('js/file-upload/compiled.js')); ?>"></script>
    <link rel="stylesheet" href="<?php echo e(asset('js/file-upload/css/jquery.fileupload.css')); ?>">
    <?php echo $__env->make('admin.equipes.equipes-assets', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>