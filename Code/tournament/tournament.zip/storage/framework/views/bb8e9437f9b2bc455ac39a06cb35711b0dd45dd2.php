

<?php $__env->startSection('page-title', 'Torneio e Batalhas'); ?>

<?php $__env->startSection('content'); ?>
<div class="container text-center">
    <h1 class="text-uppercase font-bold">Iniciar Torneio</h1>
    <a href="#" class="btn btn-primary btn-lg action-button iniciar-torneio">
        <span class="glyphicon glyphicon-play-circle glyphicon-margin-right"></span>
        Iniciar Torneio
    </a>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('assets'); ?>
    <script>
        $(function () {
            $('.iniciar-torneio').click(function () {
                if (confirm('Tem certeza que deseja iniciar um novo torneio? Todas as batalhas serão apagadas e geradas novamente.')) {
                    window.location.href = '<?php echo e(url('admin/torneio/iniciar')); ?>';
                }
            })
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>