

<?php $__env->startSection('page-title', 'Chaveamento'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row less-gutter">
        <div class="col-sm-3">
            <div class="media dark">
                <div class="media-left">
                    <a href="#" target="_blank">
                        <img class="media-object foto-equipe-chaveamento" src="/images/robot_placeholder.png" alt="FOTO">
                    </a>
                </div>
                <div class="media-body">
                    <div class="clearfix">
                        <div class="panel panel-dark" style="float: left; font-size: 14px;">
                            <div class="panel-heading">
                                Equipe1
                            </div>
                        </div>
                        <div style="float: left;">
                            X
                        </div>
                        <div class="panel panel-dark" style="float: right; font-size: 14px;">
                            <div class="panel-heading">
                                Equipe2
                            </div>
                        </div>
                    </div>
                </div>
                <div class="media-right">
                    <a href="#" target="_blank">
                        <img class="media-object foto-equipe-chaveamento" src="/images/robot_placeholder.png" alt="FOTO">
                    </a>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>