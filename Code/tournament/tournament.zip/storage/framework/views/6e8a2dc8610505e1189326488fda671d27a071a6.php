<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title><?php echo e(trim(View::yieldContent('page-title'))); ?> - <?php echo e(config('app.name', 'Laravel')); ?></title>
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/custom-theme.css')); ?>" rel="stylesheet">
    <script>
        window.Laravel = <?php echo json_encode([
                'csrfToken' => csrf_token(),
        ]); ?>
    </script>
    <script src="<?php echo e(asset('js/socket.io.js')); ?>"></script>
</head>
<body>
    <?php echo $__env->yieldContent('content'); ?>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <script src="<?php echo e(asset('js/noty/js/noty/packaged/jquery.noty.packaged.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/noty/js/noty/themes/relax.js')); ?>"></script>
    <?php echo $__env->make('public-configs', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <script src="<?php echo e(asset('js/Notify.js')); ?>"></script>
    <script src="<?php echo e(asset('js/Alerter.js')); ?>"></script>
    <script src="<?php echo e(asset('js/Responses.js')); ?>"></script>
    <script>
        $(function () {
            $('[data-toggle="tooltip"]').tooltip();
            $('div.alert').not('.alert-important').delay(3000).fadeOut(350);

            $('.table-responsive').on('show.bs.dropdown', function () {
                $('.table-responsive').css("overflow", "visible");
            });

            $('.table-responsive').on('hide.bs.dropdown', function () {
                $('.table-responsive').css("overflow", "auto");
            });
        });
    </script>
    <?php echo $__env->yieldContent('assets'); ?>
</body>
</html>