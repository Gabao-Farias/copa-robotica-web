

<?php $__env->startSection('page-title', 'Batalhas do Torneio'); ?>

<?php $__env->startSection('content'); ?>
<div class="wrapper-md">
	<h1 class="font-bold">Batalhas do Torneio</h1>
    <div class="row no-gutter" style="margin-bottom: 5px;">
        <div class="col-sm-6">
            <?php echo e(Form::open(['url' => url('admin/torneio/batalhas'), 'method' => 'GET', 'class' => 'form-inline busca-batalha'])); ?>

                <div class="form-group">
                    <label for="fase-torneio">Fase do Torneio:</label>
                    <?php echo e(Form::select('fase_torneio', ["" => "Todas"] + config('torneio.fases_torneio'), $faseTorneio, ['class' => 'form-control', 'id' => 'fase-torneio'])); ?>

                </div>

                <div class="form-group">
                    <label for="status-batalha">Status da Batalha:</label>
                    <?php echo e(Form::select('status_batalhas', ["" => "Todos"] + config('torneio.status_batalha'), $statusBatalhas, ['class' => 'form-control', 'id' => 'status-batalha'])); ?>

                </div>
                <div class="form-group">
                    <button type="submit" class="btn btn-default">
                        Buscar
                    </button>
                </div>
                <div class="form-group">
                    <a href="<?php echo e(url('admin/torneio/batalhas')); ?>" title="Desfazer Busca" class="text-danger" data-toggle="tooltip" style="margin-left: 10px;">
                        <span class="glyphicon glyphicon-remove"></span>
                    </a>
                </div>
            <?php echo e(Form::close()); ?>

        </div>
        <div class="col-sm-4">
            <strong><?php echo e($batalhas1->count() + $batalhas2->count()); ?> batalhas encontradas.</strong>
        </div>
    </div>
	<?php if($batalhas1->count()): ?>
		<div class="row less-gutter">
		    <div class="col-md-6">
		        <?php echo $__env->make('admin.partials.batalha-template', ['batalhas' => $batalhas1, 'view_only' => false], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		    </div>
		    <div class="col-md-6">
		        <?php echo $__env->make('admin.partials.batalha-template', ['batalhas' => $batalhas2, 'view_only' => false], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		    </div>
		</div>
	<?php else: ?>
		<div class="alert alert-warning alert-panel alert-important">
			Não há dados disponíveis no momento.
		</div>
	<?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('assets'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>