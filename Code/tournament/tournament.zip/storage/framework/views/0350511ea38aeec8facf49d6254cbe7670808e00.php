<div class="panel<?php echo e(isset($darkTheme) ? ' panel-dark' : ' panel-default'); ?>" style="margin-top: 20px;">
    <div class="panel-heading font-bold">
        Pontos Registrados
    </div>
    <ul class="list-group<?php echo e((isset($darkTheme) && $darkTheme) ? ' dark' : ''); ?>">
        <?php if($pontos->count()): ?>
            <?php $__currentLoopData = $pontos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ponto): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <li class="list-group-item clearfix">
                    <?php echo e(config('torneio.nomes_golpes.'.$ponto->tipo_ponto)); ?> <?php if($ponto->pontos): ?> (+<?php echo e($ponto->pontos); ?> Pontos) <?php endif; ?>
                    <?php if(! isset($hideControls) || ! $hideControls): ?>
                    <span class="remove-ponto pull-right text-danger" id="<?php echo e($ponto->id); ?>" style="cursor: pointer;" title="Remover" data-toggle="tooltip" data-equipe-nome="<?php echo e($equipe->nome); ?>" data-ataque-nome="<?php echo e(config('torneio.nomes_golpes.'.$ponto->tipo_ponto)); ?>">
                        <span class="glyphicon glyphicon-remove"></span>
                    </span>
                    <?php endif; ?>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        <?php else: ?>
            <li class="list-group-item list-group-item-warning alert-important">Não há pontos ainda.</li>
        <?php endif; ?>
    </ul>
</div>