window.Lang = {
	status_round: {
		nao_iniciada: "Não Iniciado",
		em_andamento: "Em Andamento",
		parada: "Parado",
		concluida: "Concluído"
	},

	nome_golpes: {
	    vitoria: "Vitória (Round)",
		ippon: "Ippon",
		waza_ari: "Waza-Ari",
		yuko: "Yuko",
		koka: "Koka",
		yusei_gashi: "Yusei-Gashi"
	},

    pontos_golpes: {
	    vitoria: "",
	    ippon: "Vence Round",
        waza_ari: "+10",
        yuko: "+6 Pontos",
        koka: "+4 oponente",
        yusei_gashi: "+2 oponente"
    }
};